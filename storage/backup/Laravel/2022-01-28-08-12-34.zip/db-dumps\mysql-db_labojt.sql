
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_user` bigint NOT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_category` bigint unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `articles_slug_unique` (`slug`),
  KEY `articles_id_category_foreign` (`id_category`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Rerum soluta cum sit quo.','rerum-soluta-cum-sit-quo','2022-01-20 13:44:17','2022-01-20 13:44:17'),(2,'Qui porro ut minima vel.','qui-porro-ut-minima-vel','2022-01-20 13:44:17','2022-01-20 13:44:17'),(3,'Est beatae est laudantium.','est-beatae-est-laudantium','2022-01-20 13:44:17','2022-01-20 13:44:17'),(4,'Sequi facere nisi illum.','sequi-facere-nisi-illum','2022-01-20 13:44:17','2022-01-20 13:44:17'),(5,'Eum neque aut optio cumque.','eum-neque-aut-optio-cumque','2022-01-20 13:44:17','2022-01-20 13:44:17'),(6,'Eum pariatur aut id natus.','eum-pariatur-aut-id-natus','2022-01-20 13:44:17','2022-01-20 13:44:17'),(7,'Culpa nesciunt qui quibusdam.','culpa-nesciunt-qui-quibusdam','2022-01-20 13:44:17','2022-01-20 13:44:17'),(8,'Rem aut at sint voluptatem.','rem-aut-at-sint-voluptatem','2022-01-20 13:44:17','2022-01-20 13:44:17'),(9,'Sunt rem aut itaque fugit.','sunt-rem-aut-itaque-fugit','2022-01-20 13:44:17','2022-01-20 13:44:17'),(10,'Ut suscipit quasi eos.','ut-suscipit-quasi-eos','2022-01-20 13:44:17','2022-01-20 13:44:17'),(11,'Est esse sed dolores sint ea.','est-esse-sed-dolores-sint-ea','2022-01-20 13:44:17','2022-01-20 13:44:17'),(12,'Labore id quaerat dolor rem.','labore-id-quaerat-dolor-rem','2022-01-20 13:44:17','2022-01-20 13:44:17'),(13,'Facere ut at aut voluptatum.','facere-ut-at-aut-voluptatum','2022-01-20 13:44:17','2022-01-20 13:44:17'),(14,'Autem corporis id dolores ut.','autem-corporis-id-dolores-ut','2022-01-20 13:44:17','2022-01-20 13:44:17'),(15,'Quod ea eum id.','quod-ea-eum-id','2022-01-20 13:44:17','2022-01-20 13:44:17'),(16,'Rem quo inventore at aut.','rem-quo-inventore-at-aut','2022-01-20 13:44:17','2022-01-20 13:44:17'),(17,'Omnis quod eaque et rem.','omnis-quod-eaque-et-rem','2022-01-20 13:44:17','2022-01-20 13:44:17'),(18,'Magni aperiam aut nulla.','magni-aperiam-aut-nulla','2022-01-20 13:44:17','2022-01-20 13:44:17'),(19,'Et amet similique ab.','et-amet-similique-ab','2022-01-20 13:44:17','2022-01-20 13:44:17'),(20,'Sit sunt ut qui aut esse.','sit-sunt-ut-qui-aut-esse','2022-01-20 13:44:17','2022-01-20 13:44:17'),(21,'Ducimus et modi ipsa.','ducimus-et-modi-ipsa','2022-01-20 13:44:17','2022-01-20 13:44:17'),(22,'Dolor ipsam mollitia dicta.','dolor-ipsam-mollitia-dicta','2022-01-20 13:44:17','2022-01-20 13:44:17'),(23,'Dolores vel error optio.','dolores-vel-error-optio','2022-01-20 13:44:17','2022-01-20 13:44:17'),(24,'Quae saepe aut harum ex.','quae-saepe-aut-harum-ex','2022-01-20 13:44:17','2022-01-20 13:44:17'),(25,'Omnis iste rerum sint.','omnis-iste-rerum-sint','2022-01-20 13:44:17','2022-01-20 13:44:17'),(26,'Pariatur consectetur non ut.','pariatur-consectetur-non-ut','2022-01-20 13:44:17','2022-01-20 13:44:17'),(27,'Eveniet eveniet enim vel et.','eveniet-eveniet-enim-vel-et','2022-01-20 13:44:17','2022-01-20 13:44:17'),(28,'Ut ab ut culpa delectus sed.','ut-ab-ut-culpa-delectus-sed','2022-01-20 13:44:17','2022-01-20 13:44:17'),(29,'Est hic iste fuga nobis quis.','est-hic-iste-fuga-nobis-quis','2022-01-20 13:44:17','2022-01-20 13:44:17'),(30,'Aut excepturi repellat in et.','aut-excepturi-repellat-in-et','2022-01-20 13:44:17','2022-01-20 13:44:17'),(31,'Ea laborum tempore ut qui.','ea-laborum-tempore-ut-qui','2022-01-20 13:44:17','2022-01-20 13:44:17'),(32,'Ut cumque commodi qui.','ut-cumque-commodi-qui','2022-01-20 13:44:17','2022-01-20 13:44:17'),(33,'Ea quis at nemo.','ea-quis-at-nemo','2022-01-20 13:44:17','2022-01-20 13:44:17'),(34,'Quaerat ex ea consequatur.','quaerat-ex-ea-consequatur','2022-01-20 13:44:17','2022-01-20 13:44:17'),(35,'Maiores dolor aperiam et sit.','maiores-dolor-aperiam-et-sit','2022-01-20 13:44:17','2022-01-20 13:44:17'),(36,'Et laborum sed ut quia quia.','et-laborum-sed-ut-quia-quia','2022-01-20 13:44:17','2022-01-20 13:44:17'),(37,'Ea dolorem aperiam et nemo.','ea-dolorem-aperiam-et-nemo','2022-01-20 13:44:17','2022-01-20 13:44:17'),(38,'Aliquid qui quia quod est.','aliquid-qui-quia-quod-est','2022-01-20 13:44:17','2022-01-20 13:44:17'),(39,'Illo quis autem aut.','illo-quis-autem-aut','2022-01-20 13:44:17','2022-01-20 13:44:17'),(40,'Mollitia harum sint omnis.','mollitia-harum-sint-omnis','2022-01-20 13:44:17','2022-01-20 13:44:17'),(41,'Sed sit qui sunt ad.','sed-sit-qui-sunt-ad','2022-01-20 13:44:17','2022-01-20 13:44:17'),(42,'Saepe et ab possimus quia.','saepe-et-ab-possimus-quia','2022-01-20 13:44:17','2022-01-20 13:44:17'),(43,'Et porro velit quam aut est.','et-porro-velit-quam-aut-est','2022-01-20 13:44:17','2022-01-20 13:44:17'),(44,'Qui aut officiis fuga et qui.','qui-aut-officiis-fuga-et-qui','2022-01-20 13:44:17','2022-01-20 13:44:17'),(45,'Dolorum dolorem ut et.','dolorum-dolorem-ut-et','2022-01-20 13:44:17','2022-01-20 13:44:17'),(46,'Non quia non dolorem.','non-quia-non-dolorem','2022-01-20 13:44:17','2022-01-20 13:44:17'),(47,'Dicta ad culpa deleniti sint.','dicta-ad-culpa-deleniti-sint','2022-01-20 13:44:17','2022-01-20 13:44:17'),(48,'Suscipit et quo rerum qui.','suscipit-et-quo-rerum-qui','2022-01-20 13:44:17','2022-01-20 13:44:17'),(49,'Dicta aut soluta esse non ut.','dicta-aut-soluta-esse-non-ut','2022-01-20 13:44:17','2022-01-20 13:44:17'),(50,'Rem modi minus unde laborum.','rem-modi-minus-unde-laborum','2022-01-20 13:44:17','2022-01-20 13:44:17'),(51,'Dolore culpa omnis qui.','dolore-culpa-omnis-qui','2022-01-20 13:44:17','2022-01-20 13:44:17'),(52,'Quia explicabo ut tempore.','quia-explicabo-ut-tempore','2022-01-20 13:44:17','2022-01-20 13:44:17'),(53,'Itaque quis modi veritatis.','itaque-quis-modi-veritatis','2022-01-20 13:44:17','2022-01-20 13:44:17'),(54,'Consequatur enim culpa harum.','consequatur-enim-culpa-harum','2022-01-20 13:44:17','2022-01-20 13:44:17'),(55,'Molestiae odit ea molestias.','molestiae-odit-ea-molestias','2022-01-20 13:44:17','2022-01-20 13:44:17'),(56,'Et ex nemo cum aut.','et-ex-nemo-cum-aut','2022-01-20 13:44:17','2022-01-20 13:44:17'),(57,'Est quis aut fuga id quo.','est-quis-aut-fuga-id-quo','2022-01-20 13:44:17','2022-01-20 13:44:17'),(58,'Ut et in fuga dolor.','ut-et-in-fuga-dolor','2022-01-20 13:44:17','2022-01-20 13:44:17'),(59,'Ab eos in aut velit aut.','ab-eos-in-aut-velit-aut','2022-01-20 13:44:17','2022-01-20 13:44:17'),(60,'Quia non voluptas et.','quia-non-voluptas-et','2022-01-20 13:44:17','2022-01-20 13:44:17'),(61,'Ad magni enim quae autem.','ad-magni-enim-quae-autem','2022-01-20 13:44:17','2022-01-20 13:44:17'),(62,'Porro fugit nam amet debitis.','porro-fugit-nam-amet-debitis','2022-01-20 13:44:17','2022-01-20 13:44:17'),(63,'Dolorem et alias nostrum.','dolorem-et-alias-nostrum','2022-01-20 13:44:17','2022-01-20 13:44:17'),(64,'Harum ut et eum architecto.','harum-ut-et-eum-architecto','2022-01-20 13:44:17','2022-01-20 13:44:17'),(65,'A quasi incidunt est.','a-quasi-incidunt-est','2022-01-20 13:44:17','2022-01-20 13:44:17'),(66,'Et consequuntur rem quo eum.','et-consequuntur-rem-quo-eum','2022-01-20 13:44:17','2022-01-20 13:44:17'),(67,'Et eos odit ut magni sed.','et-eos-odit-ut-magni-sed','2022-01-20 13:44:17','2022-01-20 13:44:17'),(68,'Eos vel exercitationem aut.','eos-vel-exercitationem-aut','2022-01-20 13:44:17','2022-01-20 13:44:17'),(69,'Animi et et amet facere.','animi-et-et-amet-facere','2022-01-20 13:44:17','2022-01-20 13:44:17'),(70,'Rerum dicta animi molestiae.','rerum-dicta-animi-molestiae','2022-01-20 13:44:17','2022-01-20 13:44:17'),(71,'Et sed et et repellat quo.','et-sed-et-et-repellat-quo','2022-01-20 13:44:17','2022-01-20 13:44:17'),(72,'In aut est quae.','in-aut-est-quae','2022-01-20 13:44:17','2022-01-20 13:44:17'),(73,'Unde vel magnam rerum.','unde-vel-magnam-rerum','2022-01-20 13:44:17','2022-01-20 13:44:17'),(74,'Quidem unde harum quis.','quidem-unde-harum-quis','2022-01-20 13:44:17','2022-01-20 13:44:17'),(75,'Cum et eveniet ut harum.','cum-et-eveniet-ut-harum','2022-01-20 13:44:17','2022-01-20 13:44:17'),(76,'Nam sunt eligendi ad itaque.','nam-sunt-eligendi-ad-itaque','2022-01-20 13:44:17','2022-01-20 13:44:17'),(77,'Sequi ut quod et.','sequi-ut-quod-et','2022-01-20 13:44:17','2022-01-20 13:44:17'),(78,'Et quia qui quia.','et-quia-qui-quia','2022-01-20 13:44:17','2022-01-20 13:44:17'),(79,'Et dolores et corrupti id.','et-dolores-et-corrupti-id','2022-01-20 13:44:17','2022-01-20 13:44:17'),(80,'Qui alias rerum facere quis.','qui-alias-rerum-facere-quis','2022-01-20 13:44:17','2022-01-20 13:44:17'),(81,'Et iusto ipsum vitae.','et-iusto-ipsum-vitae','2022-01-20 13:44:17','2022-01-20 13:44:17'),(82,'Impedit et omnis atque.','impedit-et-omnis-atque','2022-01-20 13:44:17','2022-01-20 13:44:17'),(83,'Et quas sequi reprehenderit.','et-quas-sequi-reprehenderit','2022-01-20 13:44:17','2022-01-20 13:44:17'),(84,'Cum et qui illo et quia iure.','cum-et-qui-illo-et-quia-iure','2022-01-20 13:44:17','2022-01-20 13:44:17'),(85,'Et quo assumenda ea aut.','et-quo-assumenda-ea-aut','2022-01-20 13:44:17','2022-01-20 13:44:17'),(86,'Laudantium eos corporis ut.','laudantium-eos-corporis-ut','2022-01-20 13:44:17','2022-01-20 13:44:17'),(87,'Vel quia non sed.','vel-quia-non-sed','2022-01-20 13:44:17','2022-01-20 13:44:17'),(88,'Et at illo quod sed.','et-at-illo-quod-sed','2022-01-20 13:44:17','2022-01-20 13:44:17'),(89,'Sit quasi voluptatem qui eos.','sit-quasi-voluptatem-qui-eos','2022-01-20 13:44:17','2022-01-20 13:44:17'),(90,'Laboriosam fugiat est qui.','laboriosam-fugiat-est-qui','2022-01-20 13:44:17','2022-01-20 13:44:17'),(91,'Rerum omnis ut amet ullam.','rerum-omnis-ut-amet-ullam','2022-01-20 13:44:17','2022-01-20 13:44:17'),(92,'Est et qui qui.','est-et-qui-qui','2022-01-20 13:44:17','2022-01-20 13:44:17'),(93,'Est aut libero rerum et et.','est-aut-libero-rerum-et-et','2022-01-20 13:44:17','2022-01-20 13:44:17'),(94,'Quisquam nemo sit sit sint.','quisquam-nemo-sit-sit-sint','2022-01-20 13:44:17','2022-01-20 13:44:17'),(95,'Et ab cumque magni.','et-ab-cumque-magni','2022-01-20 13:44:17','2022-01-20 13:44:17'),(96,'Non veritatis nisi eos.','non-veritatis-nisi-eos','2022-01-20 13:44:17','2022-01-20 13:44:17'),(97,'Et omnis aut vero tempora.','et-omnis-aut-vero-tempora','2022-01-20 13:44:17','2022-01-20 13:44:17'),(98,'Ad aut totam porro ea et.','ad-aut-totam-porro-ea-et','2022-01-20 13:44:17','2022-01-20 13:44:17'),(99,'Corporis quam nihil tempora.','corporis-quam-nihil-tempora','2022-01-20 13:44:17','2022-01-20 13:44:17'),(100,'Aut suscipit aut qui et.','aut-suscipit-aut-qui-et','2022-01-20 13:44:17','2022-01-20 13:44:17');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `connection` text COLLATE utf8_unicode_ci NOT NULL,
  `queue` text COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `menu_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_user` bigint unsigned DEFAULT NULL,
  `id_menu` bigint unsigned DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_users_id_user_foreign` (`id_user`),
  KEY `menu_users_id_menu_foreign` (`id_menu`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `menu_users` WRITE;
/*!40000 ALTER TABLE `menu_users` DISABLE KEYS */;
INSERT INTO `menu_users` VALUES (2,1,1,NULL,'2022-01-21 05:36:51','2022-01-21 05:36:51'),(3,1,2,NULL,'2022-01-21 05:36:51','2022-01-21 05:36:51'),(4,1,3,NULL,'2022-01-21 05:36:51','2022-01-21 05:36:51');
/*!40000 ALTER TABLE `menu_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `menuchiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menuchiles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `menuchiles` WRITE;
/*!40000 ALTER TABLE `menuchiles` DISABLE KEYS */;
INSERT INTO `menuchiles` VALUES (1,'Create','2022-01-21 05:43:06','2022-01-26 06:30:15'),(2,'Edit','2022-01-26 06:29:56','2022-01-26 06:30:29'),(3,'Delete','2022-01-26 06:33:28','2022-01-26 06:33:28'),(4,'View','2022-01-26 06:33:36','2022-01-26 06:33:36');
/*!40000 ALTER TABLE `menuchiles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_parent` tinyint NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,'Categories',0,'categories.index','dsf',1,'2022-01-20 13:47:53','2022-01-20 13:47:53'),(2,'Article',0,'articles.index','sdfds',1,'2022-01-21 05:35:08','2022-01-21 05:35:08'),(3,'User list',0,'users.index','fdsfds',1,'2022-01-21 05:36:19','2022-01-21 05:36:19');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2014_10_12_200000_add_two_factor_columns_to_users_table',1),(4,'2019_08_19_000000_create_failed_jobs_table',1),(5,'2019_12_14_000001_create_personal_access_tokens_table',1),(6,'2021_09_24_150023_create_sessions_table',1),(7,'2021_09_26_134247_create_settings_table',1),(8,'2021_10_18_223438_create_categories_table',1),(9,'2021_10_24_021336_create_articles_table',1),(10,'2021_10_27_015950_create_menus_table',1),(11,'2021_10_29_031936_create_menu_users_table',1),(12,'2021_10_31_115407_create_addresses_table',1),(13,'2021_11_01_130942_create_role_users_table',1),(14,'2021_11_04_065155_create_roles_table',1),(15,'2021_11_04_065236_create_permissions_table',1),(16,'2021_11_04_065653_create_user_role_table',1),(17,'2021_11_04_065712_create_permission_role_table',1),(18,'2021_11_18_021826_create_menuchiles_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_role` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `permission_id` int unsigned NOT NULL,
  `role_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permission_role` WRITE;
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` int NOT NULL,
  `level_tag` int NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int unsigned NOT NULL,
  `id_role` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_role` (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_users` WRITE;
/*!40000 ALTER TABLE `role_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','Quản trị hệ thống',1,'2022-01-25 14:25:02','2022-01-25 14:25:02'),(2,'CustomManage','Quản lý khách hàng',1,'2022-01-25 14:28:24','2022-01-25 14:28:24'),(3,'Guest','Khách',1,'2022-01-25 14:32:36','2022-01-25 14:32:36');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8_unicode_ci,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('79lCWiYuqeZz91GNUSCMiaozRIWXQZ26em7SmA0T',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiM0k4aWRKWDRXYjJjUEVrT295cFNGMnhBMlBtaFJrVDV0YlgwdnZSUyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzc6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9kYXNoYm9hcmQvcm9sZXMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjYwOiIkMnkkMTAkbXpiUVRGSHhqYTEzTVJoSnR5eXBWdTl0NC5wblJzUGZRUlVtMlYuQS9jYXBqQ2wvMFpLSWkiO30=',1643204540),('zwo5M5NGZnTm1m3FJmGFb3UJoGPfPWUzv1MeRmmX',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiMDJyOElGakNXcXZBNWdxTnVnd3YzRmM1dTBzWG1TT3lMNGVmelZXbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMCRtemJRVEZIeGphMTNNUmhKdHl5cFZ1OXQ0LnBuUnNQZlFSVW0yVi5BL2NhcGpDbC8wWktJaSI7fQ==',1643291589);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `data` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `role_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (1,3,2,NULL,NULL),(2,4,3,NULL,NULL),(3,5,1,NULL,NULL),(4,5,2,NULL,NULL),(5,5,3,NULL,NULL);
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` int DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8_unicode_ci,
  `status` int DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `current_team_id` bigint unsigned DEFAULT NULL,
  `profile_photo_path` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin','admin',NULL,'admin@gmail.com',NULL,'$2y$10$mzbQTFHxja13MRhJtyypVu9t4.pnRsPfQRUm2V.A/capjCl/0ZKIi',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL),(2,'guest','1',NULL,'guest@gmail.com',NULL,'Guest',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL),(3,'Lê Văn Nhân','lvnhan',906510173,'nhan@gmail.com',NULL,'$2y$10$rmRfGZR7uiQgUCSBo9x/l.vrzuBIbZWQqlZ9jDsHXA02aMnCXPY.2',NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-25 07:44:52','2022-01-25 07:44:52'),(4,'Nguyen tien Dũng','ntdung',906510173,'dung@gmail.com',NULL,'$2y$10$Q7jHppS8XMedUIKnKZRFiOiN6wYwvFZp209/pJm8WKzRMQdXs56Pa',NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-25 07:45:54','2022-01-25 07:45:54'),(5,'Le Minh Đức','lmduc',906510173,'tuan@gmail.com',NULL,'$2y$10$dPBcZwaSRT0VDK9PwKp8u.dUBl1e4yfqGOgSogRG1VR3hUOJ/iNtu',NULL,NULL,NULL,NULL,NULL,NULL,'2022-01-25 07:46:27','2022-01-25 07:46:27');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

