<template>
    <div class="p-2 bg-white overflow-hidden shadow-xl sm:rounded-lg sm:p-6">
        <slot></slot>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>