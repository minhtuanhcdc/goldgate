<template>
   <div class="py-2">
    <div class=" max-w-7xl mx-auto sm:px-6 lg:px-8">
        <slot></slot>
    </div>
   </div>
</template>

<script>
export default {

}
</script>

<style>

</style>