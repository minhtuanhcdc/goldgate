<?php

namespace App\Traits;

trait HasCan {
    public function getCanAttribute(){
        $currentUser = request()->user(); 
        //dd($currentUser->roles()->get());
        //$currentUser = request()->category(); 
        return [
            'view'=>$currentUser->can('view', $this),
            'create'=>$currentUser->can('create', $this),
            'update'=>$currentUser->can('update', $this),
            'delete'=>$currentUser->can('delete', $this),
        ];
    }
}