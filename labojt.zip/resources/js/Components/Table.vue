<template>
      <table >
            <thead>
                <tr class="text-left">
                    <th class="" v-for="(header,index) in headers" :key="`header-${index}`" :class="header.class || 'text-left'">
                     <div class="flex justify-between">
                     <span class="">{{header.name}}</span>
                      <span class="text-gray-400 ml-1 cursor-pointer mb-0">
                         <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 hover:text-gray-800 sm:hover:w-5 " viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M15.707 4.293a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-5-5a1 1 0 011.414-1.414L10 8.586l4.293-4.293a1 1 0 011.414 0zm0 6a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-5-5a1 1 0 111.414-1.414L10 14.586l4.293-4.293a1 1 0 011.414 0z" clip-rule="evenodd" />
                            </svg>
                      </span>
                     </div>
                     </th>                          
                </tr>
            </thead>
                <tbody>
                    <slot></slot>
                </tbody> 
        </table>
</template>

<script>
export default {
    props:{
        headers:{
            type:Array,
            required:true
        }
    }

}
</script>

<style>

</style>