<template>
    <app-layout title="Nhập thông tin">
        <template #header>
            <h2 class="font-semibold text-xl text-white leading-tight">
               Menu 
            </h2>
        </template>

        <div class="py-2">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                   Danh sách menu
                </div>
            </div>
        </div>
    </app-layout>
</template>

<script>
    import { defineComponent } from 'vue'
    import AppLayout from '@/Layouts/AppLayout.vue'
   
    export default defineComponent({
        components: {
            AppLayout,
            
        },
    })
</script>
